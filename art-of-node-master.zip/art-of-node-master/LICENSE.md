Creative Commons Share Alike (do whatever, just attribute me)
http://creativecommons.org/licenses/by-sa/2.0/